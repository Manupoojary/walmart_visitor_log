from flask import Blueprint,request,jsonify
from sqlalchemy.sql import text
from db import db
import datetime

dashboard_blueprint= Blueprint('dashboard_blueprint',__name__)

# Today's visitors

@dashboard_blueprint.route('/today-visitors')
def todayVisitors():

    currentDate=datetime.datetime.today().strftime("%Y-%m-%d")
    
    sqlTodayVisitors=text('SELECT COUNT(*) AS today_visitors from visitors_log Where date="'+currentDate+'"')
    resultData=db.engine.execute(sqlTodayVisitors)
    rawData = resultData.fetchall()

    jsondata=jsonify([dict(row) for row in rawData])
    return jsondata

#overall visitors

@dashboard_blueprint.route('/overall-visitors')
def overallVisitors():

    # currentDate=datetime.datetime.today().strftime("%Y-%m-%d")
    
    sqloverallVisitors=text('SELECT COUNT(*) AS overall_visitors from visitors_log ')
    resultData=db.engine.execute(sqloverallVisitors)
    rawData = resultData.fetchall()

    jsondata=jsonify([dict(row) for row in rawData])
    return jsondata



# male visitors today

@dashboard_blueprint.route('/male-today-visitors')
def maletodayVisitors():

    currentDate=datetime.datetime.today().strftime("%Y-%m-%d")
    
    sqlmaletodayVisitors=text('SELECT COUNT(*) AS maletoday_visitors from visitors_log Where date="'+currentDate+'" and gender=1 ')
    resultData=db.engine.execute(sqlmaletodayVisitors)
    rawData = resultData.fetchall()

    jsondata=jsonify([dict(row) for row in rawData])
    return jsondata

# female visitors today

@dashboard_blueprint.route('/female-today-visitors')
def femaletodayVisitors():

    currentDate=datetime.datetime.today().strftime("%Y-%m-%d")
    
    sqlfemaletodayVisitors=text('SELECT COUNT(*) AS femaletoday_visitors from visitors_log Where date="'+currentDate+'" and gender=2')
    resultData=db.engine.execute(sqlfemaletodayVisitors)
    rawData = resultData.fetchall()

    jsondata=jsonify([dict(row) for row in rawData])
    return jsondata

# table data

@dashboard_blueprint.route('/table-data')
def tableData():

    currentDate=datetime.datetime.today().strftime("%Y-%m-%d")

    x=''
    txtlable=''

    for a in range(1,6):
       
        if a==1:
            txtlable='Kids'
        elif a==2:
            txtlable='Tenagers'
        elif a==3:
            txtlable='Youngsters'
        elif a==4:
            txtlable='Adults'
        elif a==5:
            txtlable='Senior Citizen'
        
        for g in range(1,3):

            # today's visitors

            sqlTodayVisitors=text('SELECT COUNT(*) AS today_visitors from visitors_log Where date="'+currentDate+'" and gender='+str(g)+' and age_group='+str(a)+'')
            resultData=db.engine.execute(sqlTodayVisitors)
            rawData=resultData.fetchall()
            ageGroupGenderToday = rawData[0].today_visitors

            # overall visitors
            
            sqlOverallVisitors=text('SELECT COUNT(*) AS overall_visitors from visitors_log Where  gender='+str(g)+' and age_group='+str(a)+'')
            resultOData=db.engine.execute(sqlOverallVisitors)
            rawOData=resultOData.fetchall()
            ageGroupandGenderOverall = rawOData[0].overall_visitors

            gText=''

            if g==1:
                gText='Male'
            elif g==2:
                gText='Female'


            x+='{"gender":"'+gText+'","age_group":"'+txtlable+'","today_visitors":"'+str(ageGroupGenderToday)+'","overall_visitors":"'+str(ageGroupandGenderOverall)+'"},'

            # End of inner for loop
    # End of outer for loop

    x = x[:-1]
    jsonData = '['+x+']'
    return jsonData

# graph

@dashboard_blueprint.route('/graph-data')
def graphData():
    x = ''
    for m in range(1,13):

        sqlmonthData=text('SELECT COUNT(*) as monthly_visitors from visitors_log where MONTH(date) = "'+str(m)+'"')
        resultData = db.engine.execute(sqlmonthData)
        rawData=resultData.fetchall()
        totalMonthlyVisitors = rawData[0].monthly_visitors
        x+='{"month":"'+str(totalMonthlyVisitors)+'"},'
    
    x = x[:-1]
    jsonData='['+x+']'
    return jsonData


